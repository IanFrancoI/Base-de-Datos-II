DELIMITER $$

CREATE TRIGGER t_auditoria_clientes
AFTER UPDATE ON clientes
FOR EACH ROW
BEGIN
    INSERT INTO auditoria_clientes (
        accion,
        cliente_id,
        datos_viejos,
        datos_nuevos
    ) VALUES (
        'UPDATE',
        OLD.id,
        JSON_OBJECT('nombre', OLD.nombre, 'apellido', OLD.apellido, 'email', OLD.email),
        JSON_OBJECT('nombre', NEW.nombre, 'apellido', OLD.apellido, 'email', NEW.email)
    );
END$$

DELIMITER ;
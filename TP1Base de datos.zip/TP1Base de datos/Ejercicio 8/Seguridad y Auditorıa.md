# Administracion, Seguridad y Mantenimiento

## Seguridad y Auditorıa
- Simular una auditor´ıa simple con triggers que registren toda modificaci´on en una tabla Clientes.

### Tabla utilizada
- `Auditoria_Clientes`: {id,operacion,cliente_id,fecha}

### Solucion Paso a 
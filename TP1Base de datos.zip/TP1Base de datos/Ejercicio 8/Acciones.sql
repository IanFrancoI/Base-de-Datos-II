-- Insertar un cliente
INSERT INTO clientes (nombre, apellido, email) 
VALUES ('Lucho', 'Guardese', 'lucho@example.com'), 
        ('Noe', 'Humbert', 'Noe@example.com'), 
        ('Ivan', 'Guardese', 'Noe@example.com'),
        ('Ian', 'Ibañez', 'Ian@example.com');

-- Actualizar el cliente para disparar el trigger
UPDATE clientes
SET nombre = 'Luciano Facundo', 
    email = 'luciano@example.com'
WHERE id = 1;

-- Consultar la tabla de auditoría
SELECT * FROM auditoria_clientes;
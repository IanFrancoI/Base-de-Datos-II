# Optimizacion de Consultas, Indices y Vistas

### Tablas utilizada:
- `productos` : {id,categoria,marca,precio}

### Creacion de indice
- Se crea un indice en la columna `categoria` de la tabla `productos`
- Se crea un indice en la columna `marca` de la tabla `productos`
- Se crea un indice en la columna `categoria` y `marca` de la tabla `productos`

### Comparacion de indices
- En la comparacion de ambos indices, se puede observar que el indice en la columna `marca` y `categoria` es mas rapido que el indice en la columna `categoria` o `marca`, esto debido a que el indice en la columna `marca` y `categoria` tiene mas datos que el indice en la columna `categoria` o `marca`.
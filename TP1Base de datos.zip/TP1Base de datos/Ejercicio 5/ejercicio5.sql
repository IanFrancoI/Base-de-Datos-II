CREATE TABLE Productos (
    id SERIAL PRIMARY KEY,
    categoria VARCHAR(50),
    marca VARCHAR(50),
    precio NUMERIC
);

SELECT * FROM Productos
WHERE categoria = 'Electronica' AND marca = 'Samsung';

-- Se crea el índice en la columna "categoria" y "marca" por separado
CREATE INDEX idx_categoria ON Productos(categoria); -- Se crea el índice en la columna 'categoria'
CREATE INDEX idx_marca ON Productos(marca);
EXPLAIN SELECT * FROM Productos
WHERE categoria = 'Electronica' AND marca = 'Samsung';

-- Se crea el índice en las columnas "categoria" y "marca" juntos para optimizar la consulta
CREATE INDEX idx_categoria_marca ON Productos(categoria, marca);
EXPLAIN SELECT * FROM Productos
WHERE categoria = 'Electronica' AND marca = 'Samsung';

CREATE TABLE Estudiantes (
    id_estudiante INT PRIMARY KEY,
    nombre VARCHAR(50),
    apellido VARCHAR(50),
    dni INT,
    email VARCHAR(100),
    carrera VARCHAR(50)
);

CREATE TABLE Inscripciones (
    id_curso INT,
    id_estudiante INT,
    id_inscripcion INT,
    nombre VARCHAR(50),
    id_profesor INT,
    PRIMARY KEY (id_curso, id_estudiante, id_inscripcion),
    FOREIGN KEY (id_estudiante) REFERENCES Estudiantes(id_estudiante)
);
# Fundamentos, Integridad y Concurrencia

### Tablas Utilizadas
- **Estudiantes**:{id_estudiante, nombre, apellido, dni, email, carrera}
- **Inscripciones**:{id_curso, id_estudiante,id_inscripcion, nombre, id_profesor}

### Violación de Integridad Referencial

- Si se elimina un estudiante que tiene registros en la tabla `Inscripciones`, entonces los registros en `Inscripciones` quedarían referenciando un estudiante que ya no existe.
Esto es una violación de integridad referencial porque una clave foránea no puede apuntar a un registro que no existe

### Soluciones
- **Restricción de Eliminación**: Se puede configurar la restricción de eliminación en la tabla `Inscripciones` para evitar que se eliminen registros en `Inscripciones` si hay registros relacionados en `Estudiantes`. (`ON DELETE RESTRICT`)
- **Verificación de Integridad**: Se puede implementar una verificación de integridad en la tabla `Inscripciones` para asegurarse de que los estudiantes que se inscriben en un curso existan en la tabla `Estudiantes`.(`CHECK`)
- **Eliminación en cascada**: Se puede implementar una lógica de eliminación en lote en la tabla `Inscripciones` para eliminar todas las inscripciones asociadas a un estudiante antes de eliminar el estudiante en sí. (`ON DELETE CASCADE`)

# Optimizacion de Consultas, Indices y Vistas

### Tabla utilizada:
- `productos` : {id,nombre,descripcion,precio,stock,categoria,marca,fecha_creacion}

### Uso de EXPLAIN sin indice
- Al no poseer un indice, la consulta se realiza fila por fila, lo que puede llevar a un tiempo de ejecución mas tardio.

### Uso de EXPLAIN con indice
- Al poseer un indice, la consulta tiene una mejora de rendimiento, ya que este busca en el indice y no fila por fila, lo que lo vuelve mucho mas eficiente.
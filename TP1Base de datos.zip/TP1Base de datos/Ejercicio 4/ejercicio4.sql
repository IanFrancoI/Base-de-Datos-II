CREATE TABLE Ventas (
    id SERIAL PRIMARY KEY,
    producto_id INT,
    fecha DATE,
    cantidad INT,
    total NUMERIC
);

EXPLAIN SELECT * FROM Ventas WHERE producto_id = 123;

CREATE INDEX idx_producto_id ON Ventas(producto_id);
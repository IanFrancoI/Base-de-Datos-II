# Fundamentos, Integridad y Concurrencia

### Tablas Utilizadas
- `cuentas`: {id_cuenta, usuario, saldo}

### Consecuencias de la Concurrencia

- Al actualizar el saldo de una cuenta, es posible que dos transacciones concurrentes intenten actualizar el saldo al mismo tiempo. Si ambas transacciones se ejecutan simultáneamente, es posible que ambas actualizaciones se apliquen, lo que podría llevar a un saldo incorrecto en la cuenta.
- Si una transacción intenta leer el saldo de una cuenta y luego otra transacción intenta actualizar el saldo, es posible que la segunda transacción se ejecute antes que la primera y actualice el saldo antes de que la primera transacción pueda leerlo. Esto podría llevar a lecturas incorrectas del saldo.

### READ COMMITTED
- Esta transacción lee el saldo y lo actualiza a 900.00.
- Como está en READ COMMITTED, no bloquea la lectura por mucho tiempo.
- El cambio se confirma con el COMMIT.

### SERIALIZABLE
- Esta transacción ocurre después del COMMIT de la primera, así que puede leer los datos actualizados.
- Como está en SERIALIZABLE, intenta garantizar que nadie haya modificado los datos que leyó durante su ejecución

### Posibilidades de Concurrencia
- Si la Accion 2 arranca después del COMMIT de la Accion 1, y no hay otra transacción entre medio, puede funcionar sin error.
- Si Accion 2 empieza mientras Accion 1 todavía está activa, es probable que falle con un error de serialización.

CREATE TABLE cuentas (
    id INT PRIMARY KEY,
    nombre VARCHAR(50),
    saldo DECIMAL(10,2)
);

INSERT INTO cuentas (id, nombre, saldo) VALUES (1, 'Lucho', 1000.00);
INSERT INTO cuentas (id, nombre, saldo) VALUES (2, 'Noe', 2000.00);
INSERT INTO cuentas (id, nombre, saldo) VALUES (3, 'Ivan', 3000.00);
INSERT INTO cuentas (id, nombre, saldo) VALUES (4, 'Ian', 4000.00);

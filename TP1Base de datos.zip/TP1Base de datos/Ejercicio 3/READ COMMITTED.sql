-- Accion de la primer persona 
SET TRANSACTION ISOLATION LEVEL READ COMMITTED;
BEGIN;
SELECT saldo FROM cuentas WHERE id = 1;
UPDATE cuentas SET saldo = 900.00 WHERE id = 1;
COMMIT;

-- Accion de la segunda persona
SET TRANSACTION ISOLATION LEVEL SERIALIZABLE;
BEGIN;
SELECT saldo FROM cuentas WHERE id = 1;  
UPDATE cuentas SET saldo = 700.00 WHERE id = 1;
COMMIT;
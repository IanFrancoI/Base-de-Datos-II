CREATE DATABASE IF NOT EXISTS ejercicio9;
USE ejercicio9;

create table integrantes(
    id int auto_increment primary key,
    nombre varchar(50) not null,
    apellido varchar(50) not null,
    ciudad varchar(50) not null
);


insert into integrantes(nombre,apellido,ciudad) values (
    ('Lucho', 'Guardese','Bahia Blanca'),
    ('Noe','Hubert','Bahia Blanca'),
    ('Ivan','Guardese','Bahia Blanca'),
    ('Ian','Ibañez','Bahia Blanca')
);


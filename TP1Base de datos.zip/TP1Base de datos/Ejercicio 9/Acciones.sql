-- Eliminacion de la tabla Integrantes
USE ejercicio9;
DROP TABLE Integrantes;
SHOW TABLES;

-- Consulta sobre la tabla de integrantes
USE ejercicio9;
SELECT * FROM Integrantes;


# Administracion, Seguridad y Mantenimiento

## Backup y Restore
- Documentar paso a paso como hacer un backup completo en MySQL o PostgreSQL y como restaurarlo. Simular una perdida de datos y su posterior recuperacion.

### Paso a paso
1. Crear una base de datos en MySQL (`ejercicio9`)
2. Crear una tabla en MySQL (`ejercicio9.integrantes`)
3. Insertar datos en la tabla
4. Crear un backup de la base de datos utilizando el comando `mysqldump` (mysqldump -u root -p ejercicio9 > backup_ejercicio9.sql)
5. Luego se simula la perdida de datos, se elimina la base de datos
6. Se restaura la base de datos utilizando el comando `mysql` (mysql -u root -p ejercicio9 < backup_ejercicio9.sql)
7. Realizamos una nueva consulta para comprobar que los datos se han restaurado correctamente
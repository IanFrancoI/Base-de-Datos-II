CREATE TABLE Ventas (
    id SERIAL PRIMARY KEY,
    producto_id INT,
    fecha DATE,
    cantidad INT
);

CREATE VIEW Ventas_Mensuales AS
SELECT 
    producto_id,
    DATE_TRUNC('month', fecha) AS mes,
    SUM(cantidad) AS total_vendido
FROM Ventas
GROUP BY producto_id, DATE_TRUNC('month', fecha);


SELECT producto_id, total_vendido
FROM Ventas_Mensuales
WHERE mes = '2024-01-01'
ORDER BY total_vendido DESC
LIMIT 5;


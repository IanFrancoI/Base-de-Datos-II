# Optimizacion de Consultas, Indices y Vistas

## Vistas

### Tabla utilizada
- `Ventas`: {id,producto_id,fecha,cantidad}

### Creacion de vistas
- Se crea la vista de `Ventas_Mensuales` la cual contiene el total de ventas por mes

### Consulta
- Se realiza una consulta a la vista de `Ventas_Mensuales` para obtener el total de ventas por mes de manera ordenada
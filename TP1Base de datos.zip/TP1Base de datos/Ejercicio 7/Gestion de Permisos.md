# Administracion, Seguridad y Mantenimiento

## Gestion de Permisos

- Crear un usuario analista que solo pueda hacer SELECT en ciertas tablas. Intentar insertar desde ese usuario y explicar el resultado.

### Solucion
- Se crea el usuario `analista` con contraseña `analista111`
- Luego se le otorga permisos de SELECT a las tablas `ventas` y `productos` pero no puede modificarlos
- Al querer insertar desde el usuario `analista` se obtiene el siguiente error: `ERROR:  permission denied for table ventas` ya que este usuario no tiene permisos de INSERT
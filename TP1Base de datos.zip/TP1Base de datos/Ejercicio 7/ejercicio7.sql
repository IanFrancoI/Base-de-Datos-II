CREATE USER analista WITH PASSWORD 'analista111';

GRANT SELECT ON Ventas TO analista;
GRANT SELECT ON Productos TO analista;

INSERT INTO Ventas (producto_id, fecha, cantidad)
VALUES (1, CURRENT_DATE, 5);
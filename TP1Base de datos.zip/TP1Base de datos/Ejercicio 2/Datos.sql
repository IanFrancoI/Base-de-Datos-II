INSERT INTO Estudiantes (id_estudiante, nombre)
VALUES (1, 'Juan Pérez');

INSERT INTO Matriculas (id_matricula, id_estudiante, id_curso)
VALUES (100, 2, 501);
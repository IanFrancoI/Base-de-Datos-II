# Fundamentos, Integridad y Concurrencia

### Tablas Utilizadas
- `Estudiantes`: {id_estudiante, nombre}
- `Inscripciones`: {id_inscripcion, id_estudiante, id_curso}

## Implementación de Restricciones

- **Este intento de inserción generará un error como:**
```sql
The INSERT statement conflicted with the FOREIGN KEY constraint.
The conflict occurred in database 'nombre_db', table 'Estudiantes', column 'id_estudiante'.
```

Eso quiere decir que la inserción no se realizó porque viola una restricción de integridad referencial. En este caso, la restricción de integridad referencial es que la columna `id_estudiante` en la tabla `Inscripciones` debe existir en la tabla `Estudiantes`.